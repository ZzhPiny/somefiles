﻿$(function(){
	(function(a) {  
	    a.fn.hoverDelay = function(c, f, g, b) {  
	        var g = g || 300,   //hover entry time  
	        b = b || 0,       //hover departure time  
	        f = f || c;  
	        var e = [],  
	        d = [];  
	        return this.each(function(h) {  
	            a(this).mouseenter(function() {  
	                var i = this;  
	                clearTimeout(d[h]);  
	                e[h] = setTimeout(function() {  
	                    c.apply(i)  
	                },  
	                g)  
	            }).mouseleave(function() {  
	                var i = this;  
	                clearTimeout(e[h]);  
	                d[h] = setTimeout(function() {  
	                    f.apply(i)  
	                },  
	                b)  
	            })  
	        })  
	    }  
	})(jQuery);  
	var width=$(window).width();
	if(width>=1440){
		$(".nav-box ul li").not($(".nav-box ul li:first-child,.nav-box ul li.header-search-fiexed")).hoverDelay(function(){
			$(this).children(".menu-child-box").css({display:"block"})
			$(this).children("a").addClass("nav-box-active")
			$(".header-bg").css({height:"430px"});
		},function  () {
			$(this).children(".menu-child-box").css({display:"none"})
			$(".header-bg").css({height:"0"});
			$(this).children("a").removeClass("nav-box-active")
		})
	}else{
		$(".nav-box ul li").not($(".nav-box ul li:first-child,.nav-box ul li.header-search-fiexed")).hoverDelay(function(){
			$(".header-bg").css({height:"350px"});
			$(this).children(".menu-child-box").css({display:"block"})
			$(this).children("a").addClass("nav-box-active")
		},function  () {
			$(".header-bg").css({height:"0"});
			$(this).children(".menu-child-box").css({display:"none"})
			$(this).children("a").removeClass("nav-box-active")
		})
	}
	$(window).on("resize",function(){
		width=$(this).width();
		if(width>=1440){
			$(".nav-box ul li").not($(".nav-box ul li:first-child,.nav-box ul li.header-search-fiexed")).hoverDelay(function(){
				$(".header-bg").css({height:"430px"});
				$(this).children(".menu-child-box").css({display:"block"})
				$(this).children("a").addClass("nav-box-active")
			},function  () {
				$(".header-bg").css({height:"0"});
				$(this).children(".menu-child-box").css({display:"none"})
				$(this).children("a").removeClass("nav-box-active")
			})
			if($(".header-search-fiexed").css("display")==="block"){
				$(".header-nav ul li").css({width:"10%"});
			}else{
				$(".header-nav ul li").css({width:"11.111111%"});
			}
		}else{
			$(".nav-box ul li").not($(".nav-box ul li:first-child,.nav-box ul li.header-search-fiexed")).hoverDelay(function(){
				$(".header-bg").css({height:"350px"});
				$(this).children(".menu-child-box").css({display:"block"})
				$(this).children("a").addClass("nav-box-active")
			},function  () {
				$(".header-bg").css({height:"0"});
				$(this).children(".menu-child-box").css({display:"none"})
				$(this).children("a").removeClass("nav-box-active")
			})
			if($(".header-search-fiexed").css("display")==="block"){
				$(".header-nav ul li").css({width:"10%"});
			}else{
				$(".header-nav ul li").css({width:"11.111111%"});
			}
		}
		$(".bannerBox").css({width:width});
		$(".banner div").css({width:width});
	})
	$(".bannerBox").css({width:width});
	$(".banner div").css({width:width});
	var t=setInterval(move,10000);
	var flag=true;
	function move(){
		if(flag){
			flag=false;
			$(".banner").animate({marginLeft:-width},1000,function(){
				$(this).children().first().appendTo($(".banner"));
				$(this).css({marginLeft:0});
				flag=true;
			})
		}
	}
	$(".bannerBox").on("mouseover",function(){
		clearInterval(t);
	}).on("mouseout",function(){
		t=setInterval(move,10000);
	})
	$(".banner-rightbtn").on("click",function(){
		move();
	})
	$(".banner-leftbtn").on("click",function(){
		if(flag){
			flag=false;
			$(".banner").css({marginLeft:-width}).children().last().prependTo($(".banner")).end().end().end().animate({marginLeft:0},1000,function(){
				flag=true;
			})
		}
	})
	$(".footer-yqlj dd span").click(function(event){
		 event.stopPropagation();
		if($(this).parent().hasClass("on")){
			$(this).parent().removeClass("on");
		}else{
			$(".footer-yqlj dd").removeClass("on");
			$(this).parent().addClass("on");	
		}
	});
	$(document).on("click",function(event){
		 event.stopPropagation();
		if($(".footer-yqlj dd").hasClass("on")){
			$(".footer-yqlj dd").removeClass("on");
		}
	})
	$(".footer-yqlj dd ul li").click(function(){
		var txt=$(this).find("a").html();
		$(this).parent().parent().find("span").html(txt);	
		$(".footer-yqlj dd").removeClass("on");
	});
	var scrollTop;
	$(document).bind("mousewheel DOMMouseScroll",function(event){
		scrollTop=$(this).scrollTop();
		if(event.originalEvent.wheelDelta>0||event.originalEvent.detail<0){
			if(width>=1440){
				if($(this).scrollTop()<600){
					$(".header-nav").removeClass("header-fixed");
					$(".header-search-fiexed").css({display:"none"});
					$(".header-input-search").css({display:"none"});
					$(".header-nav ul li").css({width:"11.111111%"});
				}else{
					$(".header-nav").addClass("header-fixed");
					$(".header-search-fiexed").css({display:"block"});
					$(".header-nav ul li").css({width:"10%"});
				}
			}else{
				if($(this).scrollTop()<600){
					$(".header-nav").removeClass("header-fixed")
					$(".header-search-fiexed").css({display:"none"});
					$(".header-input-search").css({display:"none"});
					$(".header-nav ul li").css({width:"11.111111%"});
				}else{
					$(".header-nav").addClass("header-fixed");
					$(".header-search-fiexed").css({display:"block"});
					$(".header-nav ul li").css({width:"10%"});
				}
			}
		}else{
				$(".header-nav").removeClass("header-fixed");
		}
	})
	$(".header-search-fiexed").on("click",function(event){
		 event.stopPropagation();
		$(".header-input-search").toggle();
			$(".header-input-search input").focus(function(){
				var dftval=$(this).val();
				if(dftval=="输入关键词，搜项目、公告、规则..."){
					$(this).val("");	
					$(this).css("color","#f0f0f0");
				}
			});
			$(".header-input-search input").blur(function(){
				var dftval=$(this).val();
				if(dftval==""){
					$(this).val("输入关键词，搜项目、公告、规则...");	
					$(this).css("color","#f0f0f0");
				}
			});
	})
	$(".header-search input").focus(function(){
		var dftval=$(this).val();
		if(dftval=="输入关键词，搜项目、公告、规则..."){
			$(this).val("");	
			$(this).css("color","#999");
		}else{
			$(this).css("color","#333");
		}
	});
	$(".header-search input").blur(function(){
		var dftval=$(this).val();
		if(dftval==""){
			$(this).val("输入关键词，搜项目、公告、规则...");	
			$(this).css("color","#999");
		}else{
			$(this).css("color","#333");
		}
	});
	var flag1=true;
	$(".project-xq-ul-zrfcn a").on("click",function(){
		if (flag1) {
			$(".project-Commitment-table").css({display:"block"});
		    $(this).text("隐藏");
		    flag1=false;
		}else{
			$(".project-Commitment-table").css({display:"none"});
		    $(this).text("点击查看承诺全文");
		    flag1=true;
		}
	})
	

	$('.summary').each(function(){
	    var maxwidth=73;
	    if($(this).text().length>maxwidth){
	     
	        $(this).text($(this).text().substring(0,maxwidth));
	   
	        $(this).html($(this).html()+'...');
	    }
	})
	$('.menu-media-li-txt a').each(function(){
	    var maxwidth=30;
	    if($(this).text().length>maxwidth){
	     
	        $(this).text($(this).text().substring(0,maxwidth));
	   
	        $(this).html($(this).html()+'...');
	    }
	})
})